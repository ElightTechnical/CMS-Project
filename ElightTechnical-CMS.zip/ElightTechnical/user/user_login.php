    
<?php
include '../libs/database.php'; 
include '../formatdate.php';
//include 'libs/config.php';
//Creating database Object;
$db = new database();

if(isset($_POST['login'])){
	$email = mysqli_real_escape_string($db->link,$_POST['email']);
	$pass = mysqli_real_escape_string($db->link, $_POST['password']);

	$query = "SELECT * FROM user_login WHERE email='$email' AND password = '$pass'";

	$run = $db->select($query);

	if($run->num_rows > 0){ 
	$_SESSION['email']=$email;
	header('Location: index.php');


	}else{
		echo "Email and password is not correct";
	}
}



?>


