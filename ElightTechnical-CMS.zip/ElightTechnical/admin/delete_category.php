<?php
session_start();
include '../libs/database.php';
include '../formatdate.php';
//include 'libs/config.php';
$db = new database();


//Deleting code
if(isset($_GET['delete_id'])){
  $delete_id = $_GET['delete_id'];
  $query = "DELETE FROM categories WHERE id='$delete_id'";
  $run = $db->delete($query);
}

?>