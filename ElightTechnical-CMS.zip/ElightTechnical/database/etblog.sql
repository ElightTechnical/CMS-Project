-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2018 at 12:51 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `etblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `name`, `email`, `password`) VALUES
(1, 'Santosh Adhikari', '123@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`) VALUES
(1, 'PHP & MySQL'),
(2, 'AdSense'),
(3, 'Search Engine Optimization '),
(4, 'JavaScript');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `author` varchar(100) NOT NULL,
  `tags` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category`, `title`, `content`, `author`, `tags`, `date`) VALUES
(1, 1, 'Cloud computing, it\'s types and benefits', 'These days cloud computing interrupting every sector of Information Technology (IT).  Marketing, sales, organizations, finance and all of these sectors re-engineered their application to take advantages of cloud computing.  Cloud computing is instant access computing services. All the data are stored on cloud server so we don\'t have to worry about data loss or disk failure. We can access our data anywhere any place at any time. Cloud computing has lots of advantages over Grid Computing. When we store our data such as photos, text, documents online instead of on our home computer, or use social media such as Facebook, Google photos,  Dropbox or any kind of networking site you are using a \'Cloud Computing\' services. Some most popular cloud computing example is Web-mail, Social media, Online file storage or any online business applications. Many companies providing their services from cloud some of most popular companies are\r\n\r\n\r\n\r\n\r\n\r\n    Google: Google has private cloud that it using for delivering different services to its customers or users including Google map, Translation, Web-mail any many more. \r\n    Microsoft: Microsoft has Microsoft® Share-point® online services that allows users for business intelligence. Recently Microsoft makes its office application accessible form cloud. Also we will be able to move our tools on cloud.   \r\n\r\nThere are three cloud computing deployment models or its types.\r\n\r\n    Private: It means refers to used exclusively by single user or organization. Private cloud only accessible within an organization. Private cloud can  be located on organization\'s data center. It\'s infrastructure and services maintained by private network. Private cloud is more secured and very low rates of data loss.  \r\n\r\n    Hybrid: It is combination of private and public cloud. These two types of cloud bonded together and it allowed to share data between them. Deadly combination of two different technology makes Hybrid clouds are more secured and relabel.   \r\n\r\n    Public: This type of cloud services is owned and operated by third party service providers. They are sharing their resources such as storage, server over the internet world. Microsoft Azure is one of the most popular example of public cloud service. You can access these services using web browsers with internet connection. \r\n\r\nThe most impressive benefits of cloud computing are:\r\n\r\n    Cost\r\n    Speed\r\n    Security\r\n    Global access\r\n    Performance\r\n    Flexibility\r\n    Mobile Environment\r\n    user friendly\r\n', 'Santosh Adhikari', 'Cloud, computing', '2018-10-24 04:46:45'),
(4, 2, 'How To Become Successful Blogger in 2018 ', 'Today I am going to teach you about blogging. You know how to become a successful blogger in 2018? Blogging is a good source of money.\r\n\r\nIf you are thinking about starting a new blog then you can just move ahead and start the blog.\r\n\r\nYou can start blog with zero investment.\r\n\r\nHow To Become Successful Blogger in 2018\r\n\r\n\r\nBlogger.com is part of Google, Google has given us the best tool to start blogs.\r\n\r\nTo become a sucessful blogger in 2018 just follow this tips on your blog. If you become a professional blogger, then you will earn lot of money.\r\n\r\n Tips are given below\r\n\r\n 1. Blog at Least Twice a Week\r\n\r\nIf you want to be a part time blogger then you have to blog at least two time a week. But if you want to be a full time blogger then you have to blog 1 per day. \r\n\r\n 2. Articles Must be of 500+ Word\r\n\r\nyour article must be a 500 words. you need to write minimum of 500+ Words in one 1 article. if you want to become a top blogger then you need to follow this step. in google articlesore than 500+ Words words tend to rank higher in google so, write a long content. but if you don\'t have time to write maximum of words then write atleast 500+ words in you blog. \r\n\r\n 3. Reply To Every Comment\r\n\r\nIf someone answers all of your comment on a regular basis, then you will again visit the blog. This rule will apply on you too,  if you reply all of your comments, it will be likely to come back again to your blog.\r\n\r\n 4. Follow the User Suggestion\r\n\r\nNever forget the user suggestions for example, if they suggest that your image quality is not good, make your images better. If you take suggestions from a user, they will be happy and they will share your blog and invite their friends in your blogs.\r\n\r\n5. Write Quality Content\r\n\r\nWrite a quality content and write the content yourself, don\'t copy the contents of others. Content must be a 500+ words.\r\n\r\n6. Add About Us, Contact Us and Privacy Policy Page on your blog\r\n\r\nThese pages are also needed to approve your Adsense account, so go ahead and make it now. ', 'Bijay Bastola', 'Blogger, Success', '2018-10-25 08:22:16'),
(5, 2, 'à¤ªà¥‹à¤–à¤°à¤¾ à¤ªà¤²à¥à¤Ÿà¤¨à¤²à¥‡ à¤–à¥‡à¤² à¤¹à¥à¤¨à¥‡ à¤®à¥ˆà¤¦à¤¾à¤¨à¤®à¤¾ à¤¨à¥ˆ à¤…à¤­à¥à¤¯à¤¾à¤¸ à¤—à¤°à¤¿à¤°à¤¹à¥‡à¤•à¥‹', 'à¤ªà¥‹à¤–à¤°à¤¾ à¤ªà¥à¤°à¤¿à¤®à¤¿à¤¯à¤° à¤²à¤¿à¤—à¤®à¤¾ à¤¸à¤¹à¤­à¤¾à¤—à¥€ à¥¬ à¤Ÿà¤¿à¤® à¤®à¤§à¥à¤¯à¥‡à¤•à¥‹ à¤à¤• à¤¹à¥‹ , à¤ªà¥‹à¤–à¤°à¤¾ à¤ªà¤²à¥à¤Ÿà¤¨  à¥¤ à¤¸à¥à¤¥à¤¾à¤¨à¥€à¤¯ à¤Ÿà¤¿à¤® à¤­à¤à¤•à¤¾à¤²à¥‡ à¤ªà¥‹à¤–à¤°à¤¾ à¤ªà¤²à¥à¤Ÿà¤¨à¤¸à¤¾à¤®à¥  à¤•à¥‡à¤¹à¥€ à¤¦à¤¬à¤¾à¤¬  à¤› à¥¤  à¤¤à¤° à¤…à¤µà¤¸à¤° à¤ªà¤¨à¤¿ à¤‰à¤¤à¥à¤¤à¤¿à¤•à¥ˆ à¤›à¥¤\r\n\r\nà¤¶à¤°à¤¦ à¤­à¥‡à¤·à¤¾à¤µà¤•à¤°à¤•à¥‹ à¤•à¤ªà¥à¤¤à¤¾à¤¨à¥€à¤®à¤¾ à¤°à¤¹à¥‡à¤•à¥‹ à¤ªà¥‹à¤–à¤°à¤¾ à¤ªà¤²à¥à¤Ÿà¤¨à¤²à¥‡ à¤–à¥‡à¤² à¤¹à¥à¤¨à¥‡ à¤®à¥ˆà¤¦à¤¾à¤¨à¤®à¤¾ à¤¨à¥ˆ à¤…à¤­à¥à¤¯à¤¾à¤¸ à¤—à¤°à¤¿à¤°à¤¹à¥‡à¤•à¥‹ à¤› à¥¤ à¤ªà¥‹à¤–à¤°à¤¾à¤²à¥‡ à¤‰à¤¦à¥à¤˜à¤¾à¤Ÿà¤¨ à¤–à¥‡à¤²à¤®à¤¾ à¤¶à¥à¤•à¥à¤°à¤¬à¤¾à¤° à¤¸à¤¨à¥à¤¦à¥€à¤ª à¤²à¤¾à¤®à¤¿à¤›à¤¾à¤¨à¥‡ à¤®à¤¾à¤°à¥à¤•à¥€ à¤ªà¥à¤²à¥‡à¤¯à¤° à¤°à¤¹à¥‡à¤•à¥‹ à¤µà¤¿à¤°à¤¾à¤Ÿà¤¨à¤—à¤° à¤Ÿà¤¾à¤‡à¤Ÿà¤¨à¥à¤¸à¤¸à¤à¤— à¤–à¥‡à¤²à¥à¤¦à¥ˆà¤› à¥¤ à¤˜à¤°à¥‡à¤²à¥ à¤Ÿà¥‹à¤²à¥€ à¤­à¤à¤•à¤¾à¤²à¥‡ à¤•à¥‡à¤¹à¥€ à¤¦à¤¬à¤¾à¤¬ à¤°à¤¹à¥‡à¤•à¥‹ à¤–à¥‡à¤²à¤¾à¤¡à¥€ à¤¤à¤¥à¤¾ à¤ªà¥à¤°à¤¶à¤¿à¤•à¥à¤·à¤•à¤•à¥‹ à¤­à¤¨à¤¾à¤‡ à¤› à¥¤\r\n\r\nà¤ªà¥‹à¤–à¤°à¤¾à¤²à¥‡ à¤†à¤«à¥à¤¨à¥‹ à¤Ÿà¥‹à¤²à¥€à¤®à¤¾ à¤µà¤¿à¤¦à¥‡à¤¶à¥€ à¤–à¥‡à¤²à¤¾à¤¡à¥€ à¤°à¤¾à¤–à¥‡à¤•à¥‹ à¤›à¥ˆà¤¨ à¥¤  à¤µà¤¿à¤¨à¥‹à¤¦ à¤­à¤£à¥à¤¡à¤¾à¤°à¥€, à¤²à¤²à¤¿à¤¤ à¤°à¤¾à¤œà¤µà¤‚à¤¶à¥€, à¤°à¥‹à¤¹à¤¿à¤¤ à¤ªà¥Œà¤¡à¥‡à¤² à¤° à¤®à¥‡à¤¹à¤¬à¥à¤¬ à¤†à¤²à¤® à¤ªà¥‹à¤–à¤°à¤¾à¤•à¤¾ à¤®à¥à¤–à¥à¤¯ à¤¹à¤¤à¤¿à¤¯à¤¾à¤° à¤¹à¥à¤¨à¥ à¥¤ à¤‰à¤ªà¤¾à¤§à¤¿ à¤¨à¥ˆ à¤¯à¥à¤µà¤¾ à¤° à¤…à¤¨à¥à¤­à¤µà¥€ à¤–à¥‡à¤²à¤¾à¤¡à¥€à¤•à¥‹ à¤¸à¤®à¤¿à¤¶à¥à¤°à¤£ à¤°à¤¹à¥‡à¤•à¥‹ à¤Ÿà¤¿à¤®à¤•à¥‹ à¤²à¤•à¥à¤·à¥à¤¯ à¤¹à¥‹ à¥¤\r\n\r\nà¤Ÿà¤¿à¤®à¤•à¥‹ à¤ªà¥à¤°à¤¶à¤¿à¤•à¥à¤·à¤•à¤®à¤¾ à¤µà¤¿à¤¨à¥‹à¤¦ à¤¦à¤¾à¤¸ à¤›à¤¨à¥ à¥¤   \r\n\r\nà¤ªà¥€à¤ªà¥€à¤à¤²à¤•à¤¾ à¤²à¤¾à¤—à¤¿ à¤ªà¥à¤°à¤¤à¤¿à¤¸à¥à¤ªà¤°à¥à¤§à¤¾ à¤—à¤°à¥à¤¨à¥‡ à¤Ÿà¤¿à¤®  à¤ªà¥‹à¤–à¤°à¤¾ à¤ªà¥à¤—à¥à¤¨à¥‡ à¤•à¥à¤°à¤® à¤œà¤¾à¤°à¥€ à¤› à¥¤ à¤µà¤¿à¤œà¥‡à¤¤à¤¾à¤²à¥‡ à¥¨à¥­ à¤²à¤¾à¤– à¤° à¤‰à¤ªà¤µà¤¿à¤œà¥‡à¤¤à¤¾à¤²à¥‡ à¤¦à¤¶ à¤²à¤¾à¤– à¤ªà¥à¤°à¤¸à¥à¤•à¤¾à¤° à¤ªà¤¾à¤‰à¤¨à¥‡à¤›à¤¨à¥ à¥¤ à¤¯à¥‹à¤¸à¤‚à¤—à¥ˆ à¤ªà¥‹à¤–à¤°à¤¾ à¤ªà¥à¤°à¤¿à¤®à¤¿à¤¯à¤° à¤²à¤¿à¤— à¤¸à¤°à¥à¤µà¤¾à¤§à¤¿à¤• à¤°à¤¾à¤¶à¥€à¤•à¥‹ à¤•à¥à¤°à¤¿à¤•à¥‡à¤Ÿ à¤ªà¥à¤°à¤¤à¤¿à¤¯à¥‹à¤—à¤¿à¤¤à¤¾ à¤¬à¤¨à¥‡à¤•à¥‹ à¤› à¥¤ ', 'Nepal Sharma', 'sport', '2018-10-25 09:48:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
